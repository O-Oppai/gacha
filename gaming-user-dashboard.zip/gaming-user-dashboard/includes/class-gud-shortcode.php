<?php
/**
 * Shortcode class for Gaming User Dashboard
 *
 * Handles the [gaming_user_dashboard] shortcode, asset registration, form handling, and rendering.
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'GUD_Shortcode' ) ) :

class GUD_Shortcode {

	/**
	 * Singleton instance.
	 *
	 * @var GUD_Shortcode|null
	 */
	protected static $instance = null;

	/**
	 * Get instance.
	 *
	 * @return GUD_Shortcode
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'register_assets' ) );
		add_shortcode( 'gaming_user_dashboard', array( $this, 'render_shortcode' ) );
		add_shortcode( 'gud_accounts_menu', array( $this, 'render_accounts_menu_shortcode' ) );
		add_shortcode( 'gud_verification_alert', array( $this, 'render_verification_alert_shortcode' ) );
		add_filter( 'get_avatar_url', array( $this, 'filter_wp_avatar_url' ), 10, 3 );
		add_filter( 'get_avatar_data', array( $this, 'filter_wp_avatar_data' ), 10, 2 );
	}

	/**
	 * Render verification alert shortcode for header usage.
	 *
	 * @return string
	 */
	public function render_verification_alert_shortcode() {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return '';
		}

		if ( ! is_user_logged_in() ) {
			return '';
		}

		$user_id = get_current_user_id();
		$status  = (string) get_user_meta( $user_id, 'gud_verification_status', true );
		$status  = empty( $status ) ? 'none' : $status;

		if ( ! in_array( $status, array( 'none', 'rejected' ), true ) ) {
			return '';
		}

		$unique_id     = sanitize_html_class( wp_unique_id( 'gud-verification-alert-' ) );
		$settings_url  = 'https://gamebani.ir/settings/';
		$settings_text = esc_html__( 'رفتن به فرم احراز هویت', 'gaming-user-dashboard' );

		wp_enqueue_style( 'gud-style' );

		if ( 'none' === $status ) {
			$title   = esc_html__( 'تکمیل فرم احراز هویت', 'gaming-user-dashboard' );
			$message = esc_html__( 'لطفا در اولین فرصت فرم احراز هویت خود را تکمیل نمایید تا بتوانید آکانت های خود را بفروش برسانید.', 'gaming-user-dashboard' );
			$note    = esc_html__( 'نکته : با پر کردن فرم احراز هویت تیک آبی به شما داده میشود که به منزله احراز هویت شده در سایت است. این امر به نفع شما میباشد چون خریداران به شما اعتماد میکنند و با حس امنیت بیشتری آکانت شما را میخرند و حتی درصد فروش شما بیشتر میشود.', 'gaming-user-dashboard' );
			$tag     = esc_html__( 'نیازمند اقدام', 'gaming-user-dashboard' );
			$tone    = 'action';
		} else {
			$title   = esc_html__( 'فرم احراز هویت رد شده', 'gaming-user-dashboard' );
			$message = esc_html__( 'فرم احراز هویت شما رد شده.', 'gaming-user-dashboard' );
			$note    = esc_html__( 'برای دیدن دلیل رد شدن در منوی تنظیمات به منوی فرم احراز هویت بروید و مجدد به صورت صحیح فرم خود را ارسال بفرمایید.', 'gaming-user-dashboard' );
			$tag     = esc_html__( 'نیازمند اصلاح', 'gaming-user-dashboard' );
			$tone    = 'rejected';
		}

		ob_start();
		?>
		<div class="gud-verification-alert-widget gud-alert-tone-<?php echo esc_attr( $tone ); ?>" data-gud-alert-widget="<?php echo esc_attr( $unique_id ); ?>">
			<button type="button" class="gud-verification-alert-trigger" data-gud-alert-open aria-haspopup="dialog" aria-controls="<?php echo esc_attr( $unique_id ); ?>-modal" aria-expanded="false">
				<span class="gud-verification-alert-icon" aria-hidden="true">
					<svg viewBox="0 0 24 24" role="img" focusable="false" aria-hidden="true">
						<path d="M12 2C7.03 2 3 6.03 3 11v4.53c0 .8-.31 1.56-.88 2.12L1 18.77V20h22v-1.23l-1.12-1.12a3 3 0 0 1-.88-2.12V11c0-4.97-4.03-9-9-9Zm0 20a3 3 0 0 0 2.82-2h-5.64A3 3 0 0 0 12 22Z"/>
					</svg>
				</span>
				<span class="gud-verification-alert-tag gud-verification-alert-tag-<?php echo esc_attr( $tone ); ?>"><?php echo esc_html( $tag ); ?></span>
			</button>

			<div class="gud-verification-alert-modal" id="<?php echo esc_attr( $unique_id ); ?>-modal" data-gud-alert-modal role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr( $unique_id ); ?>-title" hidden>
				<div class="gud-verification-alert-backdrop" data-gud-alert-close></div>
				<div class="gud-verification-alert-dialog" role="document">
					<button type="button" class="gud-verification-alert-close" data-gud-alert-close aria-label="<?php echo esc_attr__( 'بستن پنجره', 'gaming-user-dashboard' ); ?>">×</button>
					<div class="gud-verification-alert-header">
						<h3 id="<?php echo esc_attr( $unique_id ); ?>-title"><?php echo esc_html( $title ); ?></h3>
						<a class="gud-verification-alert-link" href="<?php echo esc_url( $settings_url ); ?>"><?php echo esc_html( $settings_text ); ?></a>
					</div>
					<p class="gud-verification-alert-message"><?php echo esc_html( $message ); ?></p>
					<p class="gud-verification-alert-note"><strong><?php echo esc_html( $note ); ?></strong></p>
				</div>
			</div>
		</div>
		<script>
			(function(){
				var root=document.querySelector('[data-gud-alert-widget="<?php echo esc_js( $unique_id ); ?>"]');
				if(!root){return;}
				var openBtn=root.querySelector('[data-gud-alert-open]');
				var modal=root.querySelector('[data-gud-alert-modal]');
				var closeBtns=root.querySelectorAll('[data-gud-alert-close]');
				if(!openBtn||!modal){return;}
				var openModal=function(){modal.hidden=false;openBtn.setAttribute('aria-expanded','true');document.body.style.overflow='hidden';};
				var closeModal=function(){modal.hidden=true;openBtn.setAttribute('aria-expanded','false');document.body.style.overflow='';};
				openBtn.addEventListener('click',openModal);
				closeBtns.forEach(function(btn){btn.addEventListener('click',closeModal);});
				document.addEventListener('keydown',function(evt){if(evt.key==='Escape'&&!modal.hidden){closeModal();}});
			})();
		</script>
		<?php
		return ob_get_clean();
	}

	/**
	 * Get the custom avatar attachment ID for a user.
	 *
	 * @param int $user_id User ID.
	 * @return int
	 */
	private function get_custom_avatar_id( $user_id ) {
		$avatar_id = get_user_meta( $user_id, 'gud_custom_avatar_id', true );
		return absint( $avatar_id );
	}


	/**
	 * Resolve a user ID from get_avatar() mixed input.
	 *
	 * @param mixed $id_or_email Avatar object source.
	 * @return int
	 */
	private function resolve_avatar_user_id( $id_or_email ) {
		if ( is_numeric( $id_or_email ) ) {
			return absint( $id_or_email );
		}

		if ( $id_or_email instanceof WP_User ) {
			return absint( $id_or_email->ID );
		}

		if ( $id_or_email instanceof WP_Post ) {
			return absint( $id_or_email->post_author );
		}

		if ( $id_or_email instanceof WP_Comment ) {
			if ( ! empty( $id_or_email->user_id ) ) {
				return absint( $id_or_email->user_id );
			}
			if ( ! empty( $id_or_email->comment_author_email ) && is_email( $id_or_email->comment_author_email ) ) {
				$user = get_user_by( 'email', $id_or_email->comment_author_email );
				return $user ? absint( $user->ID ) : 0;
			}
		}

		if ( is_string( $id_or_email ) && is_email( $id_or_email ) ) {
			$user = get_user_by( 'email', $id_or_email );
			return $user ? absint( $user->ID ) : 0;
		}

		return 0;
	}

	/**
	 * Get a custom avatar URL from attachment metadata.
	 *
	 * @param int $user_id User ID.
	 * @param int $size    Target size.
	 * @return string
	 */
	private function get_custom_avatar_url( $user_id, $size = 96 ) {
		$avatar_id = $this->get_custom_avatar_id( $user_id );
		if ( $avatar_id <= 0 ) {
			return '';
		}

		$avatar_src = wp_get_attachment_image_src( $avatar_id, array( absint( $size ), absint( $size ) ) );
		if ( empty( $avatar_src[0] ) ) {
			return '';
		}

		return esc_url_raw( $avatar_src[0] );
	}

	/**
	 * Force get_avatar_url to use uploaded WordPress avatar when available.
	 *
	 * @param string          $url         Existing avatar URL.
	 * @param int|object|mixed $id_or_email User reference.
	 * @param array           $args        Avatar args.
	 * @return string
	 */
	public function filter_wp_avatar_url( $url, $id_or_email, $args ) {
		$user_id = $this->resolve_avatar_user_id( $id_or_email );
		if ( $user_id <= 0 ) {
			return $url;
		}

		$size = isset( $args['size'] ) ? absint( $args['size'] ) : 96;
		$custom_avatar_url = $this->get_custom_avatar_url( $user_id, $size );
		if ( empty( $custom_avatar_url ) ) {
			return $url;
		}

		return $custom_avatar_url;
	}

	/**
	 * Keep get_avatar() payload in sync with the custom WordPress avatar URL.
	 *
	 * @param array $args        Avatar data args.
	 * @param mixed $id_or_email Avatar source.
	 * @return array
	 */
	public function filter_wp_avatar_data( $args, $id_or_email ) {
		$user_id = $this->resolve_avatar_user_id( $id_or_email );
		if ( $user_id <= 0 ) {
			return $args;
		}

		$size = isset( $args['size'] ) ? absint( $args['size'] ) : 96;
		$custom_avatar_url = $this->get_custom_avatar_url( $user_id, $size );
		if ( empty( $custom_avatar_url ) ) {
			return $args;
		}

		$args['url'] = $custom_avatar_url;
		$args['found_avatar'] = true;
		return $args;
	}

	/**
	 * Render a custom avatar image when available.
	 *
	 * @param int    $user_id User ID.
	 * @param int    $size    Avatar size.
	 * @param string $class   Additional CSS class names.
	 * @return string
	 */
	private function get_user_avatar_markup( $user_id, $size = 96, $class = '' ) {
		$avatar_id = $this->get_custom_avatar_id( $user_id );
		if ( $avatar_id > 0 ) {
			$image_html = wp_get_attachment_image(
				$avatar_id,
				array( $size, $size ),
				false,
				array(
					'class'   => trim( 'gud-avatar-image ' . $class ),
					'loading' => 'lazy',
					'alt'     => esc_attr__( 'آواتار کاربر', 'gaming-user-dashboard' ),
				)
			);

			if ( ! empty( $image_html ) ) {
				return $image_html;
			}
		}

		$avatar_html = get_avatar(
			$user_id,
			$size,
			'',
			esc_attr__( 'آواتار کاربر', 'gaming-user-dashboard' ),
			array(
				'class' => trim( 'gud-avatar-image ' . $class ),
			)
		);

		if ( empty( $avatar_html ) ) {
			return '';
		}

		return $avatar_html;
	}

	/**
	 * Register (but do not enqueue) assets.
	 */
	public function register_assets() {
		$version = '1.1.0';

		wp_register_style(
			'gud-style',
			plugins_url( 'assets/css/gud-style.css', dirname( __FILE__ ) ),
			array(),
			$version
		);

		wp_register_script(
			'gud-script',
			plugins_url( 'assets/js/gud-script.js', dirname( __FILE__ ) ),
			array(),
			$version,
			true
		);

		// Localize script with data if needed (kept minimal for privacy/security).
		wp_localize_script(
			'gud-script',
			'gudData',
			array(
				'nonce' => wp_create_nonce( 'gud-interaction' ),
			)
		);
	}

	/**
	 * Render the dashboard shortcode.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string HTML output
	 */
	public function render_shortcode( $atts = array() ) {
		// Shortcode should only output on frontend.
		if ( is_admin() && ! wp_doing_ajax() ) {
			return '';
		}

		// If not logged in, show friendly message.
		if ( ! is_user_logged_in() ) {
			$login_url = wp_login_url( get_permalink() );
			$message   = sprintf(
				/* translators: %s: login url */
				__( 'برای مشاهده داشبورد، لطفاً <a href="%s">وارد شوید</a>.', 'gaming-user-dashboard' ),
				esc_url( $login_url )
			);
			return '<div class="gud-locked-message">' . wp_kses_post( $message ) . '</div>';
		}

		// Get current user
		$current_user = wp_get_current_user();
		$user_id      = (int) $current_user->ID;

		// Process profile settings form if posted.
		$profile_message = '';
		if ( isset( $_POST['gud_update_profile'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$nonce_field = isset( $_POST['gud_update_profile_nonce'] ) ? wp_unslash( $_POST['gud_update_profile_nonce'] ) : '';
			if ( ! wp_verify_nonce( $nonce_field, 'gud_update_profile_action' ) ) {
				$profile_message = '<div class="gud-error">' . esc_html__( 'بررسی امنیتی تنظیمات ناموفق بود. لطفاً دوباره تلاش کنید.', 'gaming-user-dashboard' ) . '</div>';
			} elseif ( ! current_user_can( 'edit_user', $user_id ) ) {
				$profile_message = '<div class="gud-error">' . esc_html__( 'شما اجازه ویرایش این حساب را ندارید.', 'gaming-user-dashboard' ) . '</div>';
			} else {
				$new_email_raw        = isset( $_POST['gud_email'] ) ? wp_unslash( $_POST['gud_email'] ) : '';
				$new_display_name_raw = isset( $_POST['gud_display_name'] ) ? wp_unslash( $_POST['gud_display_name'] ) : '';
				$remove_avatar_raw    = isset( $_POST['gud_remove_avatar'] ) ? wp_unslash( $_POST['gud_remove_avatar'] ) : '';

				$new_email        = sanitize_email( $new_email_raw );
				$new_display_name = sanitize_text_field( $new_display_name_raw );
				$remove_avatar    = ( '1' === $remove_avatar_raw );
				$errors           = array();
				$messages         = array();

				if ( empty( $new_email ) || ! is_email( $new_email ) ) {
					$errors[] = esc_html__( 'لطفاً یک ایمیل معتبر وارد کنید.', 'gaming-user-dashboard' );
				}
				if ( empty( $new_display_name ) ) {
					$errors[] = esc_html__( 'لطفاً نام نمایشی را وارد کنید.', 'gaming-user-dashboard' );
				}

				if ( $remove_avatar ) {
					delete_user_meta( $user_id, 'gud_custom_avatar_id' );
					$messages[] = esc_html__( 'آواتار سفارشی حذف شد.', 'gaming-user-dashboard' );
				}

				if ( ! empty( $_FILES['gud_avatar_file'] ) && ! empty( $_FILES['gud_avatar_file']['name'] ) ) {
					require_once ABSPATH . 'wp-admin/includes/file.php';
					require_once ABSPATH . 'wp-admin/includes/media.php';
					require_once ABSPATH . 'wp-admin/includes/image.php';

					$avatar_upload_id = media_handle_upload( 'gud_avatar_file', 0 );
					if ( is_wp_error( $avatar_upload_id ) ) {
						$errors[] = esc_html__( 'آپلود آواتار انجام نشد. لطفاً فایل تصویر معتبر انتخاب کنید.', 'gaming-user-dashboard' );
					} elseif ( ! wp_attachment_is_image( $avatar_upload_id ) ) {
						wp_delete_attachment( $avatar_upload_id, true );
						$errors[] = esc_html__( 'فایل انتخابی تصویر نیست.', 'gaming-user-dashboard' );
					} else {
						update_user_meta( $user_id, 'gud_custom_avatar_id', $avatar_upload_id );
						$messages[] = esc_html__( 'آواتار جدید ذخیره شد.', 'gaming-user-dashboard' );
					}
				}

				if ( empty( $errors ) ) {
					$update_result = wp_update_user(
						array(
							'ID'           => $user_id,
							'user_email'   => $new_email,
							'display_name' => $new_display_name,
						)
					);
					if ( is_wp_error( $update_result ) ) {
						$errors[] = esc_html__( 'به‌روزرسانی تنظیمات انجام نشد.', 'gaming-user-dashboard' );
					} else {
						$current_user = wp_get_current_user();
						$messages[]   = esc_html__( 'تنظیمات با موفقیت ذخیره شد.', 'gaming-user-dashboard' );
					}
				}

				if ( ! empty( $errors ) ) {
					$profile_message = '<div class="gud-error">' . esc_html( implode( ' ', $errors ) ) . '</div>';
				} elseif ( ! empty( $messages ) ) {
					$profile_message = '<div class="gud-success">' . esc_html( implode( ' ', $messages ) ) . '</div>';
				}
			}
		}

		// Process identity verification form if posted.
		$verification_service = GUD_Verification::get_instance();
		$update_message       = $verification_service->handle_submission( $user_id );


		// Enqueue assets now that we know the shortcode is used.
		wp_enqueue_style( 'gud-style' );
		wp_enqueue_script( 'gud-script' );

		// Build the dashboard HTML. Escape outputs appropriately.
		$email_display        = esc_html( $current_user->user_email );
		$display_name_display = esc_html( $current_user->display_name );
		$header_avatar_markup = $this->get_user_avatar_markup( $user_id, 60, 'gud-avatar-sm' );
		$form_avatar_markup   = $this->get_user_avatar_markup( $user_id, 120, 'gud-avatar-lg' );
		$has_custom_avatar    = ( $this->get_custom_avatar_id( $user_id ) > 0 );
		$form_data            = $verification_service->get_form_data( $user_id );

		// Build structure
		ob_start();
		?>
		<div class="gud-dashboard" role="region" aria-label="<?php echo esc_attr__( 'داشبورد کاربری بازی', 'gaming-user-dashboard' ); ?>">
			<div class="gud-sidebar" role="navigation" aria-label="<?php echo esc_attr__( 'منوی داشبورد', 'gaming-user-dashboard' ); ?>">
				<ul class="gud-menu" data-gud-menu>
					<li class="gud-menu-item gud-active" data-gud-tab="verification-form"><?php echo esc_html__( 'فرم احراز هویت', 'gaming-user-dashboard' ); ?></li>
					<li class="gud-menu-item" data-gud-tab="settings"><?php echo esc_html__( 'تنظیمات', 'gaming-user-dashboard' ); ?></li>
				</ul>
			</div>

			<div class="gud-main">
				<div class="gud-header">
					<div>
						<h2 class="gud-title"><?php echo esc_html__( 'داشبورد بازیکن', 'gaming-user-dashboard' ); ?></h2>
						<div class="gud-subtitle">
							<span class="gud-username-label" aria-hidden="true"><?php echo esc_html__( 'بازیکن:', 'gaming-user-dashboard' ); ?></span>
							<span class="gud-username-value"><?php echo $display_name_display; ?></span>
						</div>
					</div>

					<div class="gud-header-avatar" aria-hidden="true">
						<?php echo wp_kses_post( $header_avatar_markup ); ?>
					</div>

					<div class="gud-user-email">
						<span class="gud-email-label"><?php echo esc_html__( 'ایمیل:', 'gaming-user-dashboard' ); ?></span>
						<span class="gud-email-value"><?php echo $email_display; ?></span>
					</div>
				</div>

				<?php
				// Any update message from POST processing
				if ( ! empty( $profile_message ) ) {
					echo wp_kses_post( $profile_message );
				}
				if ( ! empty( $update_message ) ) {
					echo wp_kses_post( $update_message );
				}
				?>

				<div class="gud-content">
					<div class="gud-tab gud-tab-active" data-gud-content="verification-form">
						<?php include plugin_dir_path( dirname( __FILE__ ) ) . 'templates/verification-form.php'; ?>
					</div>

					<div class="gud-tab" data-gud-content="settings">
						<div class="gud-section-title"><?php echo esc_html__( 'تنظیمات', 'gaming-user-dashboard' ); ?></div>

						<form method="post" class="gud-form" novalidate enctype="multipart/form-data">
							<?php wp_nonce_field( 'gud_update_profile_action', 'gud_update_profile_nonce' ); ?>
							<input type="hidden" name="gud_update_profile" value="1" />

							<div class="gud-settings-grid" role="group" aria-label="<?php echo esc_attr__( 'تنظیمات پروفایل', 'gaming-user-dashboard' ); ?>">
								<div class="gud-profile-fields">
									<div class="gud-form-row">
										<label for="gud_display_name"><?php echo esc_html__( 'نام نمایشی', 'gaming-user-dashboard' ); ?></label>
										<input id="gud_display_name" name="gud_display_name" type="text" value="<?php echo esc_attr( $current_user->display_name ); ?>" required />
									</div>

									<div class="gud-form-row">
										<label for="gud_email"><?php echo esc_html__( 'ایمیل', 'gaming-user-dashboard' ); ?></label>
										<input id="gud_email" name="gud_email" type="email" value="<?php echo esc_attr( $current_user->user_email ); ?>" required />
									</div>
								</div>

								<div class="gud-avatar-card" aria-label="<?php echo esc_attr__( 'تنظیمات آواتار', 'gaming-user-dashboard' ); ?>">
									<div class="gud-avatar-preview">
										<?php echo wp_kses_post( $form_avatar_markup ); ?>
									</div>
									<div class="gud-avatar-meta">
										<h3><?php echo esc_html__( 'تصویر پروفایل', 'gaming-user-dashboard' ); ?></h3>
										<p><?php echo esc_html__( 'آواتار حرفه‌ای خود را انتخاب کنید.', 'gaming-user-dashboard' ); ?></p>
										<div class="gud-form-row">
											<label for="gud_avatar_file"><?php echo esc_html__( 'آپلود آواتار جدید', 'gaming-user-dashboard' ); ?></label>
											<input id="gud_avatar_file" name="gud_avatar_file" type="file" accept="image/jpeg,image/png,image/webp" />
										</div>
										<?php if ( $has_custom_avatar ) : ?>
											<div class="gud-avatar-actions">
												<button type="submit" name="gud_remove_avatar" value="1" class="gud-btn gud-btn-primary gud-avatar-remove-btn"><?php echo esc_html__( 'حذف آواتار', 'gaming-user-dashboard' ); ?></button>
											</div>
										<?php endif; ?>
									</div>
								</div>
							</div>

							<div class="gud-form-row">
								<button type="submit" class="gud-btn gud-btn-primary"><?php echo esc_html__( 'ذخیره تنظیمات', 'gaming-user-dashboard' ); ?></button>
							</div>
						</form>
					</div>

				</div> <!-- .gud-content -->
			</div> <!-- .gud-main -->
		</div> <!-- .gud-dashboard -->
		<?php
		$output = ob_get_clean();

		return $output;
	}

	/**
	 * Render a dedicated accounts menu shortcode for my-accounts page.
	 *
	 * @return string
	 */
	public function render_accounts_menu_shortcode() {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return '';
		}

		if ( ! is_user_logged_in() ) {
			$login_url = wp_login_url( get_permalink() );
			$message   = sprintf(
				/* translators: %s: login url */
				__( 'برای مشاهده حساب‌ها، لطفاً <a href="%s">وارد شوید</a>.', 'gaming-user-dashboard' ),
				esc_url( $login_url )
			);
			return '<div class="gud-locked-message">' . wp_kses_post( $message ) . '</div>';
		}

		wp_enqueue_style( 'gud-style' );
		wp_enqueue_script( 'gud-script' );

		ob_start();

		$steam_listings_html = '';
		if ( shortcode_exists( 'scx_user_listings' ) ) {
			ob_start();
			echo do_shortcode( '[scx_user_listings]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$steam_listings_html = ob_get_clean();
		} else {
			$steam_listings_html = '<div class="gud-info">' . esc_html__( 'افزونه لیست آکانت‌های Steam در دسترس نیست.', 'gaming-user-dashboard' ) . '</div>';
		}

		$arknight_cards_html = '';
		if ( shortcode_exists( 'arknight_my_account_cards' ) ) {
			ob_start();
			echo do_shortcode( '[arknight_my_account_cards]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$arknight_cards_html = ob_get_clean();
		} else {
			$arknight_cards_html = '<div class="gud-info">' . esc_html__( 'افزونه کارت‌های حساب Arknight در دسترس نیست.', 'gaming-user-dashboard' ) . '</div>';
		}

		$star_rail_cards_html = '';
		if ( shortcode_exists( 'hsr_my_account_cards' ) ) {
			ob_start();
			echo do_shortcode( '[hsr_my_account_cards]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$star_rail_cards_html = ob_get_clean();
		} else {
			$star_rail_cards_html = '<div class="gud-info">' . esc_html__( 'افزونه کارت‌های حساب Star Rail در دسترس نیست.', 'gaming-user-dashboard' ) . '</div>';
		}

		$zenless_cards_html = '';
		if ( shortcode_exists( 'zzz_my_account_cards' ) ) {
			ob_start();
			echo do_shortcode( '[zzz_my_account_cards]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$zenless_cards_html = ob_get_clean();
		} else {
			$zenless_cards_html = '<div class="gud-info">' . esc_html__( 'افزونه کارت‌های حساب Zenless Zone Zero در دسترس نیست.', 'gaming-user-dashboard' ) . '</div>';
		}

		$wuthering_waves_cards_html = '';
		if ( shortcode_exists( 'ww_my_account_cards' ) ) {
			ob_start();
			echo do_shortcode( '[ww_my_account_cards]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$wuthering_waves_cards_html = ob_get_clean();
		} else {
			$wuthering_waves_cards_html = '<div class="gud-info">' . esc_html__( 'افزونه کارت‌های حساب Wuthering Waves در دسترس نیست.', 'gaming-user-dashboard' ) . '</div>';
		}
		?>
		<div class="gud-dashboard gud-accounts-only" data-gud-tabs>
			<div class="gud-sidebar" aria-label="<?php echo esc_attr__( 'منوی حساب‌های من', 'gaming-user-dashboard' ); ?>">
				<ul class="gud-menu" data-gud-menu>
					<li class="gud-menu-item gud-active" data-gud-tab="steam"><?php echo esc_html__( 'آکانت Steam', 'gaming-user-dashboard' ); ?></li>
					<li class="gud-menu-item" data-gud-tab="arknight-cards"><?php echo esc_html__( 'آکانت Arknight Endfield', 'gaming-user-dashboard' ); ?></li>
					<li class="gud-menu-item" data-gud-tab="star-rail-cards"><?php echo esc_html__( 'آکانت Star Rail', 'gaming-user-dashboard' ); ?></li>
					<li class="gud-menu-item" data-gud-tab="zenless-cards"><?php echo esc_html__( 'آکانت Zenless Zone Zero', 'gaming-user-dashboard' ); ?></li>
					<li class="gud-menu-item" data-gud-tab="wuthering-waves-cards"><?php echo esc_html__( 'آکانت Wuthering Waves', 'gaming-user-dashboard' ); ?></li>
				</ul>
			</div>

			<div class="gud-main">
				<div class="gud-content">
					<div class="gud-tab gud-tab-active" data-gud-content="steam">
						<div class="gud-section-title"><?php echo esc_html__( 'آکانت Steam', 'gaming-user-dashboard' ); ?></div>
						<div class="gud-listings-wrapper">
							<?php echo wp_kses_post( $steam_listings_html ); ?>
						</div>
					</div>

					<div class="gud-tab" data-gud-content="arknight-cards">
						<div class="gud-section-title"><?php echo esc_html__( 'آکانت Arknight Endfield', 'gaming-user-dashboard' ); ?></div>
						<div class="gud-listings-wrapper">
							<?php echo wp_kses_post( $arknight_cards_html ); ?>
						</div>
					</div>

					<div class="gud-tab" data-gud-content="star-rail-cards">
						<div class="gud-section-title"><?php echo esc_html__( 'آکانت Star Rail', 'gaming-user-dashboard' ); ?></div>
						<div class="gud-listings-wrapper">
							<?php echo wp_kses_post( $star_rail_cards_html ); ?>
						</div>
					</div>

					<div class="gud-tab" data-gud-content="zenless-cards">
						<div class="gud-section-title"><?php echo esc_html__( 'آکانت Zenless Zone Zero', 'gaming-user-dashboard' ); ?></div>
						<div class="gud-listings-wrapper">
							<?php echo wp_kses_post( $zenless_cards_html ); ?>
						</div>
					</div>

					<div class="gud-tab" data-gud-content="wuthering-waves-cards">
						<div class="gud-section-title"><?php echo esc_html__( 'آکانت Wuthering Waves', 'gaming-user-dashboard' ); ?></div>
						<div class="gud-listings-wrapper">
							<?php echo wp_kses_post( $wuthering_waves_cards_html ); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php

		return ob_get_clean();
	}
}

endif;


/**
 * Public helper: get a user avatar URL with dashboard custom-avatar override.
 *
 * @param int   $user_id User ID.
 * @param array $args    Avatar args for get_avatar_url.
 * @return string
 */
function gud_get_user_avatar_url( $user_id, $args = array() ) {
	$user_id = absint( $user_id );
	if ( $user_id <= 0 ) {
		return '';
	}

	return get_avatar_url( $user_id, $args );
}
