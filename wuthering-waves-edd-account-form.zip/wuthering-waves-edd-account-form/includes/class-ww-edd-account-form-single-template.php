<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WW_EDD_Account_Form_Single_Template {
	const TEMPLATE_FILE = 'templates/single-ww-account.php';

	/**
	 * Register single template hooks.
	 */
	public function hooks() {
		add_filter( 'template_include', array( $this, 'load_single_download_template' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * @param string $template Current selected template.
	 * @return string
	 */
	public function load_single_download_template( $template ) {
		if ( ! $this->is_target_single_download() ) {
			return $template;
		}

		$custom_template = WW_EDD_FORM_DIR . self::TEMPLATE_FILE;
		if ( file_exists( $custom_template ) ) {
			return $custom_template;
		}

		return $template;
	}

	/**
	 * Register/enqueue assets for the single product template.
	 */
	public function enqueue_assets() {
		wp_register_style( 'ww-account-single-style', WW_EDD_FORM_URL . 'assets/css/single-account.css', array(), WW_EDD_FORM_VERSION );
		wp_register_script( 'ww-account-single-script', WW_EDD_FORM_URL . 'assets/js/single-account.js', array(), WW_EDD_FORM_VERSION, true );

		if ( $this->is_target_single_download() ) {
			wp_enqueue_style( 'ww-account-single-style' );
			wp_enqueue_script( 'ww-account-single-script' );

			$ww_single_seo_css = <<<'CSS'
.ww-single-account__seo-title{margin:-12px 0 18px;font-size:16px;line-height:1.8;color:var(--ww-text-dim,#9fb2dd);font-weight:700;}
.ww-single-account__keywords{margin:0;padding:0;list-style:none;display:flex;flex-wrap:wrap;gap:8px;}
.ww-single-account__keywords li{padding:6px 10px;border-radius:999px;background:rgba(79,209,255,.12);border:1px solid rgba(79,209,255,.35);font-size:12px;color:#dce9ff;}
.ww-single-account__keywords li a{color:inherit;text-decoration:none;}
.ww-single-account__keywords li a:hover,.ww-single-account__keywords li a:focus{text-decoration:underline;}
CSS;

			wp_add_inline_style( 'ww-account-single-style', $ww_single_seo_css );
		}
	}

	/**
	 * @return bool
	 */
	private function is_target_single_download() {
		if ( ! is_singular( 'download' ) ) {
			return false;
		}

		if ( ! taxonomy_exists( WW_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_TAXONOMY ) ) {
			return false;
		}

		return has_term(
			WW_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_SLUG,
			WW_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_TAXONOMY,
			get_queried_object_id()
		);
	}
}
