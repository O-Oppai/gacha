<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WW_EDD_Account_Form_Home_Slider {
	const SHORTCODE = 'ww_accounts_slider';

	/**
	 * @var WW_EDD_Account_Form_Product_Cards
	 */
	private $product_cards;

	/**
	 * @param WW_EDD_Account_Form_Product_Cards $product_cards Product cards service.
	 */
	public function __construct( WW_EDD_Account_Form_Product_Cards $product_cards ) {
		$this->product_cards = $product_cards;
	}

	public function register_shortcode() {
		add_shortcode( self::SHORTCODE, array( $this, 'render_shortcode' ) );
	}

	public function register_assets() {
		wp_register_style( 'ww-home-slider-style', WW_EDD_FORM_URL . 'assets/css/home-slider.css', array( 'ww-account-cards-style' ), WW_EDD_FORM_VERSION );
		wp_register_script( 'ww-home-slider-script', WW_EDD_FORM_URL . 'assets/js/home-slider.js', array(), WW_EDD_FORM_VERSION, true );
	}

	/**
	 * @param array<string,mixed> $atts Shortcode attributes.
	 * @return string
	 */
	public function render_shortcode( $atts ) {
		wp_enqueue_style( 'ww-account-cards-style' );
		wp_enqueue_style( 'ww-home-slider-style' );
		wp_enqueue_script( 'ww-account-cards-script' );
		wp_enqueue_script( 'ww-home-slider-script' );

		if ( ! post_type_exists( 'download' ) ) {
			return '<p class="ww-product-cards__message">' . esc_html__( 'Easy Digital Downloads فعال نیست.', 'wuthering-waves-edd-account-form' ) . '</p>';
		}

		$atts = shortcode_atts(
			array(
				'title'          => 'آکانت های Wuthering Waves',
				'button_text'    => 'مشاهده همه',
				'button_url'     => home_url( '/buy-wuthering-waves-account/' ),
				'posts_per_page' => 12,
				'orderby'        => 'date',
				'order'          => 'DESC',
			),
			$atts,
			self::SHORTCODE
		);

		$query_args = array(
			'post_type'      => 'download',
			'post_status'    => 'publish',
			'posts_per_page' => max( 1, absint( $atts['posts_per_page'] ) ),
			'orderby'        => sanitize_key( $atts['orderby'] ),
			'order'          => 'ASC' === strtoupper( (string) $atts['order'] ) ? 'ASC' : 'DESC',
			'no_found_rows'  => true,
		);

		if ( taxonomy_exists( WW_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_TAXONOMY ) ) {
			$query_args['tax_query'] = array(
				array(
					'taxonomy' => WW_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_TAXONOMY,
					'field'    => 'slug',
					'terms'    => WW_EDD_Account_Form_Frontend::DOWNLOAD_CATEGORY_SLUG,
				),
			);
		}

		$query = new WP_Query( $query_args );
		if ( ! $query->have_posts() ) {
			return '<p class="ww-product-cards__message">' . esc_html__( 'فعلاً محصولی برای نمایش وجود ندارد.', 'wuthering-waves-edd-account-form' ) . '</p>';
		}

		$cards = $this->product_cards->prepare_cards_data( $query, false );
		wp_reset_postdata();

		$template_file = WW_EDD_FORM_DIR . 'templates/shortcode-ww-home-slider.php';
		if ( ! file_exists( $template_file ) ) {
			return '';
		}

		$slider_id = uniqid( 'ww-home-slider-', false );

		ob_start();
		require $template_file;
		return ob_get_clean();
	}
}
