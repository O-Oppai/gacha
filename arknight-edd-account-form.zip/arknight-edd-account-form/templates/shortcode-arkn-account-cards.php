<?php
/**
 * Product cards shortcode template.
 *
 * @var array<int,array<string,mixed>> $cards
 * @var bool                          $show_filters
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $show_filters ) ) {
	$show_filters = true;
}

if ( $show_filters ) {
	$server_options    = array();
	$character_map     = array();
	$weapon_map        = array();

	foreach ( $cards as $card_item ) {
		if ( ! empty( $card_item['server_raw'] ) ) {
			$server_options[] = sanitize_text_field( (string) $card_item['server_raw'] );
		}

		if ( ! empty( $card_item['characters_hover_items'] ) && is_array( $card_item['characters_hover_items'] ) ) {
			foreach ( $card_item['characters_hover_items'] as $character ) {
				$name  = isset( $character['name'] ) ? sanitize_text_field( (string) $character['name'] ) : '';
				$image = isset( $character['image'] ) ? esc_url_raw( (string) $character['image'] ) : '';
				if ( '' === $name ) {
					continue;
				}
				if ( ! isset( $character_map[ $name ] ) || ( '' === $character_map[ $name ] && '' !== $image ) ) {
					$character_map[ $name ] = $image;
				}
			}
		}

		if ( ! empty( $card_item['weapons_hover_items'] ) && is_array( $card_item['weapons_hover_items'] ) ) {
			foreach ( $card_item['weapons_hover_items'] as $weapon ) {
				$name  = isset( $weapon['name'] ) ? sanitize_text_field( (string) $weapon['name'] ) : '';
				$image = isset( $weapon['image'] ) ? esc_url_raw( (string) $weapon['image'] ) : '';
				if ( '' === $name ) {
					continue;
				}
				if ( ! isset( $weapon_map[ $name ] ) || ( '' === $weapon_map[ $name ] && '' !== $image ) ) {
					$weapon_map[ $name ] = $image;
				}
			}
		}
	}

	$server_options = array_values( array_unique( array_filter( $server_options ) ) );

	$character_options = array_keys( $character_map );
	$weapon_options    = array_keys( $weapon_map );

	natcasesort( $server_options );
	natcasesort( $character_options );
	natcasesort( $weapon_options );
}

?>
<?php if ( $show_filters ) : ?>
	<div class="arkn-product-filters" data-arkn-filters>
		<div class="arkn-product-filters__row-main">
			<div class="arkn-product-filters__field">
				<label for="arkn-authority-min"><?php esc_html_e( 'آتوریتی (از)', 'arknight-edd-account-form' ); ?></label>
				<input id="arkn-authority-min" type="number" min="1" max="60" value="1" data-arkn-filter="authority-min" />
			</div>

			<div class="arkn-product-filters__field">
				<label for="arkn-authority-max"><?php esc_html_e( 'آتوریتی (تا)', 'arknight-edd-account-form' ); ?></label>
				<input id="arkn-authority-max" type="number" min="1" max="60" value="60" data-arkn-filter="authority-max" />
			</div>

			<div class="arkn-product-filters__field arkn-product-filters__field--select" data-arkn-custom-select>
				<label><?php esc_html_e( 'سرور', 'arknight-edd-account-form' ); ?></label>
				<button type="button" class="arkn-product-filters__select-trigger" data-arkn-select-trigger aria-expanded="false">
					<span data-arkn-select-label><?php esc_html_e( 'همه سرورها', 'arknight-edd-account-form' ); ?></span>
				</button>
				<div class="arkn-product-filters__select-menu" data-arkn-select-menu hidden>
					<button type="button" data-value=""><?php esc_html_e( 'همه سرورها', 'arknight-edd-account-form' ); ?></button>
					<?php foreach ( $server_options as $server ) : ?>
						<button type="button" data-value="<?php echo esc_attr( $server ); ?>"><?php echo esc_html( $server ); ?></button>
					<?php endforeach; ?>
				</div>
				<input type="hidden" value="" data-arkn-filter="server" />
			</div>

			<div class="arkn-product-filters__field">
				<label for="arkn-price-min"><?php esc_html_e( 'قیمت (از)', 'arknight-edd-account-form' ); ?></label>
				<input id="arkn-price-min" type="number" min="0" step="10000" data-arkn-filter="price-min" placeholder="2000000" />
			</div>

			<div class="arkn-product-filters__field">
				<label for="arkn-price-max"><?php esc_html_e( 'قیمت (تا)', 'arknight-edd-account-form' ); ?></label>
				<input id="arkn-price-max" type="number" min="0" step="10000" data-arkn-filter="price-max" placeholder="3400000" />
			</div>
					<div class="arkn-product-filters__row-sub">
			<div class="arkn-product-filters__field arkn-product-filters__field--select" data-arkn-custom-select>
				<label><?php esc_html_e( 'مرتب‌سازی', 'arknight-edd-account-form' ); ?></label>
				<button type="button" class="arkn-product-filters__select-trigger" data-arkn-select-trigger aria-expanded="false">
					<span data-arkn-select-label><?php esc_html_e( 'جدیدترین', 'arknight-edd-account-form' ); ?></span>
				</button>
				<div class="arkn-product-filters__select-menu" data-arkn-select-menu hidden>
					<button type="button" data-value="min-price"><?php esc_html_e( 'کمترین قیمت', 'arknight-edd-account-form' ); ?></button>
					<button type="button" data-value="max-price"><?php esc_html_e( 'بیشترین قیمت', 'arknight-edd-account-form' ); ?></button>
					<button type="button" data-value="oldest"><?php esc_html_e( 'قدیمی‌ترین', 'arknight-edd-account-form' ); ?></button>
					<button type="button" data-value="newest"><?php esc_html_e( 'جدیدترین', 'arknight-edd-account-form' ); ?></button>
				</div>
				<input type="hidden" value="newest" data-arkn-filter="sort" />
			</div>
		</div>
		</div>



		<div class="arkn-product-filters__checkbox-panels">
			<div class="arkn-product-filters__checkbox-group">
				<p><?php esc_html_e( 'فیلتر کاراکترها', 'arknight-edd-account-form' ); ?></p>
				<div class="arkn-product-filters__scrollbox">
					<?php foreach ( $character_options as $character_name ) : ?>
						<?php $image = isset( $character_map[ $character_name ] ) ? (string) $character_map[ $character_name ] : ''; ?>
						<label class="arkn-product-filters__media-check">
							<input type="checkbox" value="<?php echo esc_attr( $character_name ); ?>" data-arkn-filter="character" />
							<span class="arkn-product-filters__media-check-body">
								<span class="arkn-product-filters__media-thumb">
									<?php if ( '' !== $image ) : ?>
										<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $character_name ); ?>" loading="lazy" />
									<?php else : ?>
										<span class="arkn-product-filters__thumb-fallback">★</span>
									<?php endif; ?>
								</span>
								<span class="arkn-product-filters__media-name"><?php echo esc_html( $character_name ); ?></span>
							</span>
						</label>
					<?php endforeach; ?>
				</div>
			</div>

			<div class="arkn-product-filters__checkbox-group">
				<p><?php esc_html_e( 'فیلتر سلاح‌ها', 'arknight-edd-account-form' ); ?></p>
				<div class="arkn-product-filters__scrollbox">
					<?php foreach ( $weapon_options as $weapon_name ) : ?>
						<?php $image = isset( $weapon_map[ $weapon_name ] ) ? (string) $weapon_map[ $weapon_name ] : ''; ?>
						<label class="arkn-product-filters__media-check">
							<input type="checkbox" value="<?php echo esc_attr( $weapon_name ); ?>" data-arkn-filter="weapon" />
							<span class="arkn-product-filters__media-check-body">
								<span class="arkn-product-filters__media-thumb">
									<?php if ( '' !== $image ) : ?>
										<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $weapon_name ); ?>" loading="lazy" />
									<?php else : ?>
										<span class="arkn-product-filters__thumb-fallback">✦</span>
									<?php endif; ?>
								</span>
								<span class="arkn-product-filters__media-name"><?php echo esc_html( $weapon_name ); ?></span>
							</span>
						</label>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>

<div class="arkn-product-cards" data-arkn-cards>
	<?php foreach ( $cards as $card_data ) : ?>
		<?php require ARKN_EDD_FORM_DIR . 'templates/partials/product-card.php'; ?>
	<?php endforeach; ?>
</div>
